#!/usr/bin/env python3
"""Gildem Craft Pro v8.5.4. Simplifica Black Craft y Royal Craft.

Uso: python INSTALAR_ACTUALIZACION.py RUTA_A_REPOSITORIO
No modifica el proyecto si falla la validación de los puntos de anclaje.
Si la base es 8.5.2, incluye la actualización de liquidez 8.5.3.
"""
from pathlib import Path
import json, subprocess, sys, shutil, re

SRC=Path(__file__).resolve().parent
DEST=Path(sys.argv[1]).expanduser().resolve() if len(sys.argv)>1 else Path.cwd()


def one(s, old, new, label):
    count=s.count(old)
    if count != 1: raise RuntimeError(f'{label}: esperaba 1 coincidencia, hay {count}. Versiones soportadas: 8.5.2 o 8.5.3.')
    return s.replace(old,new,1)


def between(s,begin,end,part,label):
    if s.count(begin)!=1 or s.count(end)!=1: raise RuntimeError(f'{label}: anclajes inesperados ({s.count(begin)}, {s.count(end)})')
    a=s.index(begin);b=s.index(end)
    if b<=a: raise RuntimeError(f'{label}: orden de anclajes inesperado')
    return s[:a]+(SRC/'parts'/part).read_text(encoding='utf-8')+'\n'+s[b:]


def patch_app(s):
    # No reemplazamos la lógica del motor económico; sustituimos solo el formulario y sus controles.
    s=between(s,'function pickScopeHtml(prefix){','async function refreshCraftItems(){','pickers.jsfrag','selector de objetos')
    s=between(s,'function branchPicker(){','function craftRateHelp(){','black-branch.jsfrag','ramas Black Craft')
    s=between(s,'function craftPage(){','const AUTO_CATEGORIES=','black-page.jsfrag','formulario Black Craft')
    s=between(s,'function renderAutoBranches(){','function refreshAutoCategoryPanels(){','royal-branches.jsfrag','ramas Royal Craft')
    s=between(s,'function autoPage(){','// Level Craft uses the same verified catalog','royal-page.jsfrag','formulario Royal Craft')
    anchor='async function refreshCraftItems(){'
    if s.count(anchor)!=1: raise RuntimeError('No se encuentra el cargador de recetas')
    s=s.replace(anchor,(SRC/'parts'/'compact-core.jsfrag').read_text(encoding='utf-8')+'\n'+anchor,1)

    # Cascada de filtros reales: checkboxes de tiers y encantamientos, no solo etiquetas visuales.
    old=" const ids=recipesForBranch(recipes,input.branch,input.tierMin,input.tierMax,input.ench,categoryForBranch(input.branch)==='foods'?260:150,'auto',id=>itemMatches(id,{mode:choice.mode,stems:choice.stems,enchExact:input.enchExact}));"
    new=" let ids=recipesForBranch(recipes,input.branch,input.tierMin,input.tierMax,input.ench,categoryForBranch(input.branch)==='foods'?260:150,'auto',id=>itemMatches(id,{mode:choice.mode,stems:choice.stems,enchExact:input.enchExact}));\n ids=ids.filter(id=>qcVariantIncluded('craft',id,input.branch));"
    s=one(s,old,new,'aplicar tiers y encantamientos Black')
    old="  const scanRefining=wantsRefining&&market!=='black'?refinementScanIds({families:refineFamilies,tierMin,tierMax,enchant,enchExact}):[];"
    new="   if(craftCats.length)pick.chosen=pick.chosen.filter(x=>qcVariantIncluded('auto',x.id,branchKeys[0]));\n"+old
    s=one(s,old,new,'aplicar tiers y encantamientos Royal')

    s=one(s," const cats=[...document.querySelectorAll('input[name=\"auto-category\"]:checked')].map(x=>x.value);",
          "  const cats=readAutoCategories();",'categoría Royal individual')
    s=one(s,"market:branchIsRoyalOnly(selectedBranch)?'royal':val('craft-market','black')", "market:'black'", 'destino fijo Black')
    s=one(s,"&&checked('craft-journals'),refiningMode:'off'", "&&(control('craft-journals')?checked('craft-journals'):true),refiningMode:'off'", 'diarios automáticos')
    s=one(s,"Math.floor(input.budget*.90),{goal:input.goal,useAll:false,capFraction,",
          "Math.floor(input.budget*(input.invest==='all'?1:.90)),{goal:input.goal,useAll:input.invest==='all',capFraction,", 'asignación de presupuesto Black')
    s=one(s,"Math.floor(budget*.90),{goal:goal==='daily'?'daily':goal,useAll:false,capFraction:",
          "Math.floor(budget*(autoPrefs.invest==='all'?1:.90)),{goal:goal==='daily'?'daily':goal,useAll:autoPrefs.invest==='all',capFraction:", 'asignación de presupuesto Royal')
    s=one(s,"market,invest:'caution',journals:false", "market,invest:autoPrefs.invest||'safe',journals:false", 'estado presupuesto Royal')

    # Los eventos del nuevo formulario no atraviesan los manejadores de filtros antiguos.
    s=one(s,"document.addEventListener('click',e=>{\n const group=", "document.addEventListener('click',e=>{\n const royalGroup=e.target.closest('[data-auto-group]');if(royalGroup){qcChooseAutoGroup(royalGroup.dataset.autoGroup);return;}\n const group=", 'categorías Royal click')
    s=one(s,"document.addEventListener('change',e=>{\n if(e.target.name==='level-category')",
          "document.addEventListener('change',e=>{\n if(qcOnChange(e.target))return;\n  if(e.target.matches('[data-qc-all]')){const prefix=e.target.dataset.qcAll;const el=control(prefix+'-item-options');if(el)el.querySelectorAll('input[data-pick-item]').forEach(x=>{x.checked=e.target.checked;});qcSaveObjectChecks(prefix);return;}\n  if(e.target.name==='level-category')",'casillas checkbox eventos')
    begin=" if(e.target.matches('[data-pick-item]')){"
    end=" if(e.target.id==='auto-branch-mode'){"
    replacement=""" if(e.target.matches('[data-pick-item]')){qcSaveObjectChecks(e.target.dataset.pickItem);return;}
  if(e.target.matches('[data-auto-branch]')){
   if(!e.target.checked){e.target.checked=true;return;}
   qcChooseAutoBranch(e.target.value);return;
  }
"""
    if s.count(begin)!=1 or s.count(end)!=1:raise RuntimeError('Eventos de selección de objetos/ramas no coinciden')
    a=s.index(begin);b=s.index(end)
    s=s[:a]+replacement+s[b:]
    # El formulario de Royal trabaja con una sola categoría almacenada, nunca con un selector antiguo oculto.
    return s


def main():
    if not (DEST/'app.js').is_file() or not (DEST/'core/allocator-v6.js').is_file() or not (DEST/'package.json').is_file():
        raise SystemExit('Selecciona la carpeta COMPLETA de Gildem Craft Pro: contiene app.js, core/ y package.json.')
    package=DEST/'package.json'
    version=json.loads(package.read_text(encoding='utf-8')).get('version')
    if version=='8.5.4':
        print('La versión 8.5.4 ya parece instalada. No se aplicaron cambios.');return
    if version not in ('8.5.2','8.5.3'):
        raise SystemExit(f'Versión {version!r} no soportada. Usa el código completo v8.5.2 o v8.5.3.')
    # Validación ANTES de aplicar la actualización de liquidez y la nueva UI.
    preview=patch_app((DEST/'app.js').read_text(encoding='utf-8'))
    if 'qcRoyalBranchPicker()' not in preview or "market:'black'" not in preview:
        raise RuntimeError('La nueva interfaz no contiene los elementos esperados')
    if version=='8.5.2':
        bundled=SRC/'liquidez_v8_5_3'/'INSTALAR_ACTUALIZACION.py'
        if not bundled.is_file():raise RuntimeError('Falta la actualización de liquidez incluida en el ZIP.')
        print('Aplicando las protecciones de mercado de v8.5.3...')
        subprocess.run([sys.executable,str(bundled),str(DEST)],check=True)
    # Segunda validación contra lo que realmente se va a grabar.
    changes={}
    app=DEST/'app.js';changes[app]=patch_app(app.read_text(encoding='utf-8'))
    css=DEST/'styles.css';origin=css.read_text(encoding='utf-8');mark='/* Gildem Craft Pro v8.5.4.'
    if mark in origin: raise RuntimeError('La hoja de estilos ya contiene esta actualización')
    changes[css]=origin+'\n'+(SRC/'parts'/'compact.css').read_text(encoding='utf-8')
    p=json.loads(package.read_text(encoding='utf-8'));p['version']='8.5.4';changes[package]=json.dumps(p,ensure_ascii=False,indent=2)+'\n'
    for path in ['sw.js','index.html','manifest.webmanifest','scripts/build.mjs','netlify/functions/health.mjs']:
        f=DEST/path
        raw=f.read_text(encoding='utf-8')
        if '8.5.3' not in raw:raise RuntimeError(f'{path}: falta versión 8.5.3 después de aplicar actualización')
        changes[f]=raw.replace('8.5.3','8.5.4')
    # Actualizar assertions antiguas que exigían controles retirados intencionadamente.
    # Las pruebas de economía y cálculo se mantienen sin modificaciones.
    stale_tests={
      'tests/v7_4-food.test.mjs':[
       ("assert.match(app,/craft-tiermin'\\)\\.value='1'/);", "assert.match(app,/ids=ids\\.filter\\(id=>qcVariantIncluded\\('craft'/);")],
      'tests/v8_3-hud-refining.test.mjs':[
       ("assert(app.includes('const available=manualBranches(branchCategory,query)'));", "assert(app.includes('manualBranches(branchCategory).map'));")],
      'tests/v8_4-compact-hud.test.mjs':[
       ("assert.equal((app.match(/selectField\\('Solo este encantamiento'/g)||[]).length,2);", "assert(app.includes('QC_ENCH=[1,2,3,4]'));"),
       ("assert(app.includes('Refinar y vender: oportunidades independientes'));", "assert(app.includes('createRefiningCandidates'));"),
       ("assert(app.includes('<section class=\"craft-compact-card craft-bonus-card\"'));", "assert(app.includes(\"qcControls('craft')\"));"),
       ("assert(app.includes('<section class=\"craft-compact-card craft-invest-card\"'));", "assert(app.includes(\"qcControls('auto')\"));")],
      'tests/v8_4_1-ui-compact.test.mjs':[
       ("assert.match(app,/<div class=\"craft-filter-row\" role=\"group\"/);", "assert.match(app,/qcControls\\('craft'\\)/);")]
    }
    for path,substitutions in stale_tests.items():
        f=DEST/path
        if not f.exists():continue
        test_source=f.read_text(encoding='utf-8')
        for old,new in substitutions:
            if test_source.count(old)==1:test_source=test_source.replace(old,new,1)
            elif test_source.count(new)==1:pass  # se permite test ya migrado
            else:raise RuntimeError(f'{path}: assertion antigua inesperada; no se modificó el proyecto')
        changes[f]=test_source
    # Escritura solamente después de todas las verificaciones.
    for f,content in changes.items():f.write_text(content,encoding='utf-8');print('Actualizado',f.relative_to(DEST))
    dest_test=DEST/'tests/v8_5_4-compact-ui.test.mjs'
    dest_test.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(SRC/'tests/v8_5_4-compact-ui.test.mjs',dest_test)
    print('Añadido',dest_test.relative_to(DEST))
    print('\nGildem Craft Pro v8.5.4 instalado sobre tu código completo.')
    print('Ejecuta en esa carpeta: npm test && npm run build')
    print('Cuando ambos pasen, publica la rama con GitHub Desktop para Netlify.')

if __name__=='__main__':
    try:main()
    except (OSError,ValueError,RuntimeError,subprocess.CalledProcessError) as e:
        raise SystemExit('No se pudo completar la actualización: '+str(e))
