# Gildem Craft Pro v8.5.4: Black Craft y Royal Craft compactos

Actualización de **interfaz y selección de recetas** para el proyecto completo. Conserva el motor de cálculo de profit, mercados, precios, liquidez, diarios y lista de compras. Incluye la protección de rotación de materiales de v8.5.3 cuando la instalación parte de v8.5.2.

## Cambios principales

- **Black Craft:** solamente Mercado Negro. Se elimina la selección Royal/mixta de esta tab.
- **Royal Craft:** solamente mercados Royal. Se elimina la selección Mercado Negro/mixta de esta tab.
- Formulario resumido: fabricar en ciudad de bono, tiers T4–T8 (selección múltiple), encantamientos .1–.4 (selección múltiple), bono diario 0/10/20% (una selección), Focus (casilla), presupuesto 5/10/15/20 millones (una selección) y uso de presupuesto completo (casilla; desmarcado = cautela).
- Se elige **una sola rama individual**, sin cuadro de búsqueda ni barrido de todas las ramas por defecto.
- Se muestran los objetos de esa rama. **Todos los objetos** marca todos; desmarca los que no quieras analizar. El filtro aplica realmente a las recetas.
- Desaparecen los formularios avanzados visibles en estas dos tabs. Los límites de riesgo, costes y validación permanecen en el motor y en los Ajustes generales cuando corresponda.
- El bono diario de 0% está disponible para no asumir falsamente un bono activo. La posibilidad de seleccionar .0 no aparece en Black Craft porque se pidieron explícitamente los encantamientos .1–.4; para ramas Royal naturalmente sin encantamiento se admite internamente .0.
- El modo "Usar todo lo posible" intenta asignar todo el silver seleccionado, pero **no obliga** a recomendar ventas sin demanda o con pérdidas.
- El refinamiento independiente sigue en el código original; esta vista simplificada de Royal Craft se centra en ramas de crafting.

## Instalación (Windows)

1. Descarga y descomprime este ZIP, conservando **todas** las carpetas incluidas.
2. En **GitHub Desktop**, abre el repositorio `drzjhon-dot/gildem-craft-pro-live` y utiliza **Repository → Show in Explorer** para abrir la carpeta con `app.js`, `core/` y `package.json`.
3. Arrastra esa **carpeta del repositorio** encima de `ACTUALIZAR_WINDOWS.bat` de esta actualización. Se necesita Python 3 y Node.js 22 para las pruebas automáticas.
4. Verifica que `npm test` y `npm run build` terminan sin errores. El BAT intenta ejecutar ambos, si npm está disponible.
5. En GitHub Desktop: **Commit to main → Push origin**. Comprueba que Netlify haya publicado el deploy de `main`. Recarga la web (Ctrl+Shift+R) para invalidar la caché anterior.
6. Verifica `https://endearing-piroshki-ea4758.netlify.app/version.json`: debe mostrar `"version": "8.5.4"` cuando el despliegue ya esté terminado.

## Alternativa (macOS/Linux/terminal Windows)

```bash
python3 INSTALAR_ACTUALIZACION.py /ruta/a/gildem-craft-pro-live
cd /ruta/a/gildem-craft-pro-live
npm test
npm run build
```

El actualizador admite como base las versiones **8.5.2 o 8.5.3**, sin necesitar instalaciones previas. Si detecta una versión diferente, o código incompatible, se detiene en vez de modificarlo a ciegas.

## Comprobaciones realizadas aquí

- Pruebas del selector de tiers y encantamientos no consecutivos: OK.
- Prueba sintética del instalador sobre la estructura de la versión 8.5.3: OK (actualización y repetición segura).
- `node --check` de los fragmentos JavaScript y del archivo sintético resultante: OK.
- **Pendiente en tu equipo:** pruebas completas de integración y ejecución real de la app, porque el repositorio completo no se pudo descargar al contenedor y la conexión de GitHub no permitió escritura. La actualización no está publicada automáticamente en Netlify.

## Consideraciones del mercado

Datos AODP son observaciones y pueden estar desactualizados. Los topes del volumen histórico no significan que esos niveles sigan disponibles. Confirma el coste real de taller y transporte si actualmente aparece en cero; no asumas que el Focus funciona sin un consumo verificado por craft.
