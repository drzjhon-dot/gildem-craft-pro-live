@echo off
chcp 65001 >nul
setlocal
set "PATCH=%~dp0INSTALAR_ACTUALIZACION.py"
if not exist "%PATCH%" (
 echo ERROR: Falta INSTALAR_ACTUALIZACION.py
 pause
 exit /b 1
)
if "%~1"=="" (
 echo Arrastra la CARPETA COMPLETA de Gildem Craft Pro sobre este .bat.
 echo Debe contener app.js, package.json y core\
 pause
 exit /b 1
)
set "TARGET=%~1"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 "%PATCH%" "%TARGET%"
) else (
 python "%PATCH%" "%TARGET%"
)
if errorlevel 1 (
 echo ERROR: revisa el mensaje anterior.
 pause
 exit /b 1
)
pushd "%TARGET%"
where npm >nul 2>nul
if not errorlevel 1 (
 echo Comprobando tests y compilacion...
 call npm test
 if errorlevel 1 goto :bad
 call npm run build
 if errorlevel 1 goto :bad
 echo Listo para publicar en GitHub + Netlify.
) else (
 echo No se encuentra npm. Instala Node.js 22 y ejecuta npm test y npm run build.
)
popd
pause
exit /b 0
:bad
echo FALLARON LAS PRUEBAS. NO PUBLIQUES esta version.
popd
pause
exit /b 1
