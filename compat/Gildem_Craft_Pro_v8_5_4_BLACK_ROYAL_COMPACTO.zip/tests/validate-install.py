#!/usr/bin/env python3
"""Synthetic integration test for the 8.5.3 -> 8.5.4 installer, without live market/network dependencies."""
from pathlib import Path
import tempfile, shutil, json, subprocess, sys
root=Path(__file__).resolve().parents[1]
base='''
function pickScopeHtml(prefix){}
function itemPickerHtml(prefix){}
function renderItemChoices(prefix){}
async function refreshCraftItems(){}
let branchCategory='armor';
function branchPicker(){}
function branchOptions(){}
function chooseBranch(){}
function changeBranchGroup(){}
function craftRateHelp(){}
function craftPage(){}
const AUTO_CATEGORIES=[];
const autoPrefs={};
function renderAutoBranches(){}
function refreshAutoCategoryPanels(){}
function autoPage(){}
// Level Craft uses the same verified catalog
function engineStub(){
 const choice={mode:'all',stems:[]};const input={branch:'boots_plate',tierMin:4,tierMax:8,ench:4,enchExact:'all',budget:1000000,invest:'all',goal:'balanced',market:'black'};
 const ids=recipesForBranch(recipes,input.branch,input.tierMin,input.tierMax,input.ench,categoryForBranch(input.branch)==='foods'?260:150,'auto',id=>itemMatches(id,{mode:choice.mode,stems:choice.stems,enchExact:input.enchExact}));
  const scanRefining=wantsRefining&&market!=='black'?refinementScanIds({families:refineFamilies,tierMin,tierMax,enchant,enchExact}):[];
 const cats=[...document.querySelectorAll('input[name="auto-category"]:checked')].map(x=>x.value);
 const somewhere={market:branchIsRoyalOnly(selectedBranch)?'royal':val('craft-market','black')};
 const flags={journals:valid&&checked('craft-journals'),refiningMode:'off'};
 const black=allocatePortfolioV6(shortlisted,Math.floor(input.budget*.90),{goal:input.goal,useAll:false,capFraction,unknownCap:0});
 const royal=allocatePortfolioV6(routes,Math.floor(budget*.90),{goal:goal==='daily'?'daily':goal,useAll:false,capFraction:.10});
 const state={budget,market,invest:'caution',journals:false};
}
document.addEventListener('click',e=>{
 const group=e.target.closest('[data-branch-group]');if(group){changeBranchGroup(group.dataset.branchGroup);return;}
});
document.addEventListener('change',e=>{
 if(e.target.name==='level-category')return;
 if(e.target.matches('[data-pick-item]')){
  const prefix=e.target.dataset.pickItem;
 }
 if(e.target.matches('[data-auto-branch]')){}
 if(e.target.id==='auto-branch-mode'){}
});
'''
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp);(d/'core').mkdir();(d/'scripts').mkdir();(d/'netlify/functions').mkdir(parents=True)
 (d/'app.js').write_text(base)
 (d/'core/allocator-v6.js').write_text('// placeholder')
 (d/'package.json').write_text(json.dumps({'name':'test','version':'8.5.3'}))
 (d/'styles.css').write_text('/* before */')
 for path in ['sw.js','index.html','manifest.webmanifest','scripts/build.mjs','netlify/functions/health.mjs']:
  (d/path).write_text('v8.5.3')
 r=subprocess.run([sys.executable,str(root/'INSTALAR_ACTUALIZACION.py'),str(d)],capture_output=True,text=True)
 if r.returncode:
  print(r.stdout,r.stderr);sys.exit(1)
 assert json.loads((d/'package.json').read_text())['version']=='8.5.4'
 app=(d/'app.js').read_text()
 for string in ['qcVariantIncluded(\'craft\'','qcVariantIncluded(\'auto\'','qcRoyalBranchPicker()','market:\'black\'']:
  assert string in app,string
 assert 'craft-branch-search' not in app[app.index('function craftPage()'):app.index('const AUTO_CATEGORIES=')]
 verify=subprocess.run(['node','--check',str(d/'app.js')],capture_output=True,text=True)
 assert verify.returncode==0,verify.stderr
 again=subprocess.run([sys.executable,str(root/'INSTALAR_ACTUALIZACION.py'),str(d)],capture_output=True,text=True)
 assert again.returncode==0 and 'ya parece instalada' in again.stdout
 print('OK: actualización aplicada, versión 8.5.4, JavaScript válido, idempotente')
